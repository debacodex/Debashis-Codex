

package com.github.debacodex.gt.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.github.debacodex.gt.R;
import com.github.debacodex.gt.activity.DetailsActivity;
import com.github.debacodex.gt.model.MyItem;

import java.util.List;

public class MyItemAdapter extends RecyclerView.Adapter<MyItemAdapter.MyViewHolder> {
	
	private Context context;
	private List<MyItem> itemList;
	private int layoutResId; // To differentiate between list and grid item layouts
	
	public MyItemAdapter(Context context, List<MyItem> itemList, int layoutResId) {
		this.context = context;
		this.itemList = itemList;
		this.layoutResId = layoutResId;
	}
	
	@NonNull
	@Override
	public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(context).inflate(layoutResId, parent, false);
		return new MyViewHolder(view);
	}
	    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        MyItem currentItem = itemList.get(position);

        holder.titleTextView.setText(currentItem.getTitle());
        Glide.with(context)
                .load(currentItem.getImageUrl())
                .placeholder(R.drawable.cast_connected) // Your placeholder image
                .error(R.drawable.access_point_network_off) // Your error image
                .into(holder.imageView);

        holder.itemContainer.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailsActivity.class);
            intent.putExtra("item_title", currentItem.getTitle());
            intent.putExtra("item_image", currentItem.getImageUrl());
            intent.putExtra("item_description", currentItem.getDescription());
            context.startActivity(intent);
        });
    }
	@Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleTextView;
        LinearLayout itemContainer; // Or whatever your root layout is

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.item_image);
            titleTextView = itemView.findViewById(R.id.item_title);
            itemContainer = itemView.findViewById(R.id.item_container);
        }
   