package com.github.debacodex.gt.fragment;

// GridFragment.java


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.debacodex.gt.R;
import com.github.debacodex.gt.adapter.MyItemAdapter;
import com.github.debacodex.gt.model.MyItem;
import java.util.ArrayList;
import java.util.List;

public class GridFragment extends Fragment {
	
	private RecyclerView recyclerView;
	private MyItemAdapter adapter;
	private List<MyItem> itemList;
	
	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_grid, container, false);
		
		recyclerView = view.findViewById(R.id.recycler_view_grid);
		// Use GridLayoutManager for grid layout
		recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2)); // 2 columns
		
		itemList = generateDummyData(); // Populate with your actual data
		adapter = new MyItemAdapter(getContext(), itemList, R.layout.item_grid);
		recyclerView.setAdapter(adapter);
		
		return view;
	}
	
	private List<MyItem> generateDummyData() {
		List<MyItem> data = new ArrayList<>();
		data.add(new MyItem("Grid Item 1", "https://picsum.photos/id/237/200/300", "Details for Grid Item 1."));
		data.add(new MyItem("Grid Item 2", "https://picsum.photos/id/1084/200/300", "Details for Grid Item 2."));
		data.add(new MyItem("Grid Item 3", "https://picsum.photos/id/1018/200/300", "Details for Grid Item 3."));
		data.add(new MyItem("Grid Item 4", "https://picsum.photos/id/1040/200/300", "Details for Grid Item 4."));
		data.add(new MyItem("Grid Item 5", "https://picsum.photos/id/1069/200/300", "Details for Grid Item 5."));
		data.add(new MyItem("Grid Item 6", "https://picsum.photos/id/1074/200/300", "Details for Grid Item 6."));
		return data;
	}
}