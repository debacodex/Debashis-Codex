package com.github.debacodex.gt.activity;

// MainActivity.java

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.github.debacodex.gt.R;
import com.github.debacodex.gt.fragment.GridFragment;
import com.github.debacodex.gt.fragment.ListFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
	
	private TabLayout tabLayout;
	private ViewPager2 viewPager;
	private ViewPagerFragmentAdapter viewPagerFragmentAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		tabLayout = findViewById(R.id.tab_layout);
		viewPager = findViewById(R.id.view_pager);
		
		viewPagerFragmentAdapter = new ViewPagerFragmentAdapter(this);
		viewPager.setAdapter(viewPagerFragmentAdapter);
		
		// Connect TabLayout with ViewPager2
		new TabLayoutMediator(tabLayout, viewPager,
		(tab, position) -> {
			switch (position) {
				case 0:
				tab.setText("List View");
				break;
				case 1:
				tab.setText("Grid View");
				break;
			}
		}).attach();
	}
	
	private static class ViewPagerFragmentAdapter extends FragmentStateAdapter {
		
		private final List<Fragment> fragmentList = new ArrayList<>();
		private final List<String> fragmentTitleList = new ArrayList<>();
		
		public ViewPagerFragmentAdapter(@NonNull FragmentActivity fragmentActivity) {
			super(fragmentActivity);
			fragmentList.add(new ListFragment());
			fragmentTitleList.add("List View");
			fragmentList.add(new GridFragment());
			fragmentTitleList.add("Grid View");
		}
		
		@NonNull
		@Override
		public Fragment createFragment(int position) {
			return fragmentList.get(position);
		}
		
		@Override
		public int getItemCount() {
			return fragmentList.size();
		}
		
		public CharSequence getPageTitle(int position) {
			return fragmentTitleList.get(position);
		}
	}
}