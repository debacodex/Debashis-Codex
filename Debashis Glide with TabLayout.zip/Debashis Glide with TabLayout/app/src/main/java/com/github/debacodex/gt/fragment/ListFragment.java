package com.github.debacodex.gt.fragment;

// ListFragment.java

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.debacodex.gt.R;
import com.github.debacodex.gt.adapter.MyItemAdapter;
import com.github.debacodex.gt.model.MyItem;

import java.util.ArrayList;
import java.util.List;

public class ListFragment extends Fragment {
	
	private RecyclerView recyclerView;
	private MyItemAdapter adapter;
	private List<MyItem> itemList;
	
	@Nullable
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_list, container, false);
		
		recyclerView = view.findViewById(R.id.recycler_view_list);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		
		itemList = generateDummyData(); // Populate with your actual data
		adapter = new MyItemAdapter(getContext(), itemList, R.layout.item_list);
		recyclerView.setAdapter(adapter);
		
		return view;
	}
	
	private List<MyItem> generateDummyData() {
		List<MyItem> data = new ArrayList<>();
		data.add(new MyItem("Item 1 (List)", "https://via.placeholder.com/150/FF5733/FFFFFF?text=Item1", "This is the description for Item 1 in the list view."));
		data.add(new MyItem("Item 2 (List)", "https://via.placeholder.com/150/33FF57/FFFFFF?text=Item2", "This is the description for Item 2 in the list view."));
		data.add(new MyItem("Item 3 (List)", "https://via.placeholder.com/150/3357FF/FFFFFF?text=Item3", "This is the description for Item 3 in the list view."));
		data.add(new MyItem("Item 4 (List)", "https://via.placeholder.com/150/FFFF33/FFFFFF?text=Item4", "This is the description for Item 4 in the list view."));
		data.add(new MyItem("Item 5 (List)", "https://via.placeholder.com/150/FF33FF/FFFFFF?text=Item5", "This is the description for Item 5 in the list view."));
		return data;
	}
}