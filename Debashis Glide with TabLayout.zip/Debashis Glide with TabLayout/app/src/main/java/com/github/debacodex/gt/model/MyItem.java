package com.github.debacodex.gt.model;

// MyItem.java
package com.example.yourappname.model;

public class MyItem {
	private String title;
	private String imageUrl;
	private String description; // For details
	
	public MyItem(String title, String imageUrl, String description) {
		this.title = title;
		this.imageUrl = imageUrl;
		this.description = description;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getImageUrl() {
		return imageUrl;
	}
	
	public String getDescription() {
		return description;
	}
}