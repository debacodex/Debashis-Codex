package com.github.debacodex.glide;

// MainActivity.java
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
	
	private RecyclerView recyclerView;
	private ItemAdapter itemAdapter;
	private List<Item> itemList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		recyclerView = findViewById(R.id.recyclerView);
		itemList = new ArrayList<>();
		
		// Populate with some dummy data
		populateItemList();
		
		// For a vertical list
		// recyclerView.setLayoutManager(new LinearLayoutManager(this));
		
		// For a grid with 2 columns
		recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
		
		itemAdapter = new ItemAdapter(this, itemList);
		recyclerView.setAdapter(itemAdapter);
	}
	
	private void populateItemList() {
		// Add your actual data here. For demonstration, using dummy data.
		itemList.add(new Item("Mountain View", "https://picsum.photos/id/237/200/300", "A beautiful view of the mountains."));
		itemList.add(new Item("Forest Path", "https://picsum.photos/id/1084/200/300", "A serene path through the forest."));
		itemList.add(new Item("City Lights", "https://picsum.photos/id/1018/200/300", "Dazzling city lights at night."));
		itemList.add(new Item("Ocean Sunset", "https://picsum.photos/id/1040/200/300", "A vibrant sunset over the ocean."));
		itemList.add(new Item("Desert Oasis", "https://picsum.photos/id/1069/200/300", "An oasis in the vast desert."));
		itemList.add(new Item("Abstract Art", "https://picsum.photos/id/1074/200/300", "A colorful piece of abstract art."));
		itemList.add(new Item("Green Fields", "https://picsum.photos/id/1070/200/300", "Lush green fields under a clear sky."));
		itemList.add(new Item("Northern Lights", "https://picsum.photos/id/1073/200/300", "The spectacular aurora borealis."));
		itemList.add(new Item("Bridge Over Water", "https://picsum.photos/id/1076/200/300", "An elegant bridge spanning calm waters."));
		itemList.add(new Item("Hot Air Balloons", "https://picsum.photos/id/1077/200/300", "Colorful hot air balloons in the sky."));
	}
}