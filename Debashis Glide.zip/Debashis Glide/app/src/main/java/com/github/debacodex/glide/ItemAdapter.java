package com.github.debacodex.glide;

// ItemAdapter.java
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
	
	private List<Item> itemList;
	private Context context;
	
	public ItemAdapter(Context context, List<Item> itemList) {
		this.context = context;
		this.itemList = itemList;
	}
	
	@NonNull
	@Override
	public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
		return new ItemViewHolder(view);
	}
	
	@Override
	public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
		Item currentItem = itemList.get(position);
		
		holder.itemNameTextView.setText(currentItem.getName());
		
		// Load image using Glide
		Glide.with(context)
		.load(currentItem.getImageUrl())
		.placeholder(R.drawable.ic_launcher_background) // Optional: placeholder while loading
		.error(R.drawable.ic_launcher_foreground)     // Optional: image to show on error
		.into(holder.itemImageView);
		
		holder.itemView.setOnClickListener(v -> {
			// Handle item click - navigate to DetailsActivity
			Intent intent = new Intent(context, DetailsActivity.class);
			intent.putExtra("ITEM_NAME", currentItem.getName());
			intent.putExtra("ITEM_IMAGE_URL", currentItem.getImageUrl());
			intent.putExtra("ITEM_DESCRIPTION", currentItem.getDescription());
			context.startActivity(intent);
		});
	}
	
	@Override
	public int getItemCount() {
		return itemList.size();
	}
	
	public static class ItemViewHolder extends RecyclerView.ViewHolder {
		ImageView itemImageView;
		TextView itemNameTextView;
		
		public ItemViewHolder(@NonNull View itemView) {
			super(itemView);
			itemImageView = itemView.findViewById(R.id.itemImageView);
			itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
		}
	}
}