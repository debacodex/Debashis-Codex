package com.github.debacodex.glide;

// DetailsActivity.java
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailsActivity extends AppCompatActivity {
	
	private ImageView detailImageView;
	private TextView detailNameTextView;
	private TextView detailDescriptionTextView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details); // You'll create this layout
		
		detailImageView = findViewById(R.id.detailImageView);
		detailNameTextView = findViewById(R.id.detailNameTextView);
		detailDescriptionTextView = findViewById(R.id.detailDescriptionTextView);
		
		// Get data from the intent
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			String itemName = extras.getString("ITEM_NAME");
			String itemImageUrl = extras.getString("ITEM_IMAGE_URL");
			String itemDescription = extras.getString("ITEM_DESCRIPTION");
			
			detailNameTextView.setText(itemName);
			detailDescriptionTextView.setText(itemDescription);
			
			Glide.with(this)
			.load(itemImageUrl)
			.placeholder(R.drawable.ic_launcher_background)
			.error(R.drawable.ic_launcher_foreground)
			.into(detailImageView);
		}
	}
}